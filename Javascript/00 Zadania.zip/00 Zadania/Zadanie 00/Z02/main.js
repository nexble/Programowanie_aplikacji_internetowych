let a = parseInt(prompt("Podaj a: ",""));
let b = parseInt(prompt("Podaj b: ",""));
let c = parseInt(prompt("Podaj c: ",""));
let d = parseInt(prompt("Podaj d: ",""));

let suma = a+b+c+d;
let srednia = suma/4;

console.log("a = "+a);
console.log("b = "+b);
console.log("c = "+c);
console.log("d = "+d);
console.log("srednia = "+srednia);

document.write(suma);