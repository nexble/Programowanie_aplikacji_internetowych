let imie = prompt("Podaj swoje imie: ","Jan");

console.log(imie)
document.write("<h1>Czesc "+imie+" :)</h1>");
document.write("<h2> Milo cie widziec na naszej stronie.</h2>");
